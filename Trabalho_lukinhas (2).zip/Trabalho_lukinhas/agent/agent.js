const grpc = require("@grpc/grpc-js");
const protoLoader = require("@grpc/proto-loader");
const path = require("path");
const { print } = require("pdf-to-printer");
const fs = require("fs");

// 📌 Caminho do arquivo printer.proto
const PROTO_PATH = path.join(__dirname, "../grpc-proto/printer.proto");

// Carrega o proto
const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});
const proto = grpc.loadPackageDefinition(packageDefinition).printer;

// Inicializa o cliente gRPC para se conectar ao servidor
const client = new proto.PrinterService(
  "localhost:50051",
  grpc.credentials.createInsecure()
);

console.log("🖨️ Agent gRPC iniciado e aguardando comandos...");

// ⛔ Função local para impressão (cliente chama o server)
function enviarPDFparaImprimir(localPdfPath) {
  if (!fs.existsSync(localPdfPath)) {
    console.error("Arquivo não existe:", localPdfPath);
    return;
  }

  console.log("📨 Enviando arquivo para o servidor gRPC...");

  client.PrintPdf({ filePath: localPdfPath }, (err, response) => {
    if (err) {
      return console.error("❌ Erro ao enviar ao servidor:", err.message);
    }

    console.log("✔ Servidor respondeu:", response.message);
  });
}

// Exemplo de teste automático ao iniciar
setTimeout(() => {
  const arquivoTeste = "C:/teste.pdf"; // ❗ Mude aqui para o caminho real
  enviarPDFparaImprimir(arquivoTeste);
}, 2000);

module.exports = { enviarPDFparaImprimir };
