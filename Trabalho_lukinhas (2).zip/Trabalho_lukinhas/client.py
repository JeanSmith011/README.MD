
import grpc
import os
import printer_pb2
import printer_pb2_grpc

class PrinterClient:
    def __init__(self, host='localhost', port=50051):
        channel = grpc.insecure_channel(f'{host}:{port}')
        self.stub = printer_pb2_grpc.PrinterServiceStub(channel)

    def print_document(self, file_path):
        if not os.path.isfile(file_path):
            return False, f"Arquivo não encontrado: {file_path}"

        request = printer_pb2.PrintRequest(document=file_path)
        response = self.stub.PrintDocument(request)
        return True, response.message

if __name__ == "__main__":
    client = PrinterClient()
    test_file = r"file:///C:/Trabalho_lukinhas/Trabalho_lukinhas.pdf.pdf"
    success, msg = client(test_file)
    print("Resultado:", success, msg)