# gRPC Server Backward Compatibility Issues and Workarounds Management

## Introduction
This document lists the workarounds implemented on gRPC servers for record and reference when users need to enable a certain workaround.

## Workaround List
